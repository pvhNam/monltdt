package BaiTapLTDT;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

public abstract class Graph {
	protected int numVex;
	protected int[][] matrix;

	public Graph(int numVex, int[][] matrix) {
		this.numVex = numVex;
		this.matrix = matrix;
	}

	public Graph() {
	}

	// Tự động tạo đúng loại đồ thị
	public static Graph createGraph(int numVex, int[][] matrix) {
		if (checkUnGraph(matrix)) {
			System.out.println("Đồ thị vô hướng.");
			System.out.println();
			return new UndirectionGraph(numVex, matrix);
		} else {
			System.out.println("Đồ thị có hướng.");
			System.out.println();
			return new DirectionGraph(numVex, matrix);
		}
	}

	// Câu 1: Lấy ma trận từ file.txt
	public static Graph loadGraph(String pathFile) {
		pathFile = GetPath.getPath(pathFile);

		if (pathFile == null) {
			System.out.println("Lỗi, file không tồn tại hoặc không tìm thấy đường dẫn");
			System.exit(0);
		}

		try (BufferedReader br = new BufferedReader(new FileReader(pathFile))) {
			String line = br.readLine();
			if (line == null || line.trim().isEmpty()) {
				System.out.println("Số đỉnh không hợp lệ.");
				return null;
			}
			int numVex = Integer.parseInt(line.trim());

			int[][] matrix = new int[numVex][numVex];

			for (int i = 0; i < numVex; i++) {
				line = br.readLine();
				if (line == null || line.trim().isEmpty()) {
					System.out.println("Dữ liệu không đầy đủ trong file.");
					return null;
				}

				String[] values = line.trim().split("\\s+");
				if (values.length != numVex) {
					System.out.println("Số cột trong ma trận không đúng tại dòng " + (i + 1));
					return null;
				}
				for (int j = 0; j < numVex; j++) {
					matrix[i][j] = Integer.parseInt(values[j].trim());
				}
			}
			System.out.print("Tải file thành công. ");

			// Tự động tạo đối tượng phù hợp
			return createGraph(numVex, matrix);
		} catch (IOException e) {
			System.out.println("Lỗi khi đọc file: " + e.getMessage());
			return null;
		} catch (NumberFormatException e) {
			System.out.println("Lỗi định dạng dữ liệu trong file: " + e.getMessage());
			return null;
		}
	}

	// Câu 2. In ma trận đồ thị
	public void printMatrixGraph() {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println();
	}

	// Câu 3. Kiểm tra ma trận đồ thị có hợp lệ
	public boolean checkValid() {
		if (matrix == null)
			return false;

		for (int[] column : matrix) {
			if (matrix.length != column.length)
				return false;
		}

		return true;
	}

	// Câu 4. Kiểm tra có là đồ thị vô hướng
	public static boolean checkUnGraph(int[][] matrix) {
		int n = matrix.length;
		for (int i = 0; i < n; i++) {
			for (int j = i + 1; j < n; j++) {
				if (matrix[i][j] != matrix[j][i]) {
					return false;
				}
			}
		}
		return true;
	}

	// Câu 5. Phương thức thêm một cạnh
	public abstract void addEdge(int[][] matrix, int v1, int v2);

	// Câu 6. Phương thức xóa một cạnh
	public abstract void removeEdge(int[][] matrix, int v1, int v2);

	// Câu 7. Phương thức tính bậc của mỗi đỉnh
	public abstract int deg(int v);

	// Câu 8. Phương thức tính tổng bậc của đồ thị
	public abstract int sumDeg();

	// Câu 9. Phương thức tính tổng số đỉnh của đồ thị
	public int numVertexs() {
		return numVex;
	}

	// Câu 10. Phương thức tính tổng số cạnh của đồ thị
	public abstract int numEdges();

	// Câu 11. Phương thức kiểm tra đồ thị có liên thông
	// Đồ thị liên thông nếu có đường đi giữa 2 đỉnh bất kỳ

	public boolean checkConnect() {
		boolean[] visited = new boolean[numVex];
		Arrays.fill(visited, false);

		// Bắt đầu duyệt từ đỉnh 0 (hoặc một đỉnh bất kỳ)
		System.out.println("Bắt đầu kiểm tra liên thông từ đỉnh 0");

		DFS(0, visited);

		// Kiểm tra nếu có đỉnh nào chưa thăm
		for (int i = 0; i < numVex; i++) {
			if (!visited[i]) {
				System.out.println("Đỉnh " + i + " chưa được thăm. Đồ thị không liên thông.");
				return false;
			}
		}

		System.out.println("Tất cả các đỉnh đã được thăm. Đồ thị liên thông.");
		return true;
	}

	private void DFS(int start, boolean[] visited) {
		Stack<Integer> stack = new Stack<>();
		stack.push(start);

		while (!stack.isEmpty()) {
			int v = stack.pop();

			if (!visited[v]) {
				visited[v] = true;
				System.out.println("Thăm đỉnh " + v);

				// Duyệt tất cả các đỉnh kề
				for (int i = 0; i < numVex; i++) {
					if (matrix[v][i] == 1 && !visited[i]) {
						System.out.println(" -> Đẩy đỉnh " + i + " vào ngăn xếp để thăm tiếp theo.");
						stack.push(i);
					}
				}
			}
		}
	}

	// Câu 12. Phương thức xét tính liên thông của đồ thị
	public abstract void xetTinhLienThong();

	public abstract void diTimCacDinhLienThong(boolean[] visited, int start, List<Integer> component);

	// Câu 13. Phương thức dùng giải thuật BFS duyệt đồ thị
	public void BFSGraph() {
		boolean[] visited = new boolean[numVex];
		System.out.println("Bắt đầu duyệt đồ thị bằng BFS:");

		for (int i = 0; i < numVex; i++) {
			if (!visited[i]) {
				System.out.println("Bắt đầu từ đỉnh " + i);
				BFSGraph(i, visited);
			}
		}
	}

	// BFS bắt đầu từ một đỉnh cho trước
	public void BFSGraph(int startVex) {
		boolean[] visited = new boolean[numVex];
		BFSGraph(startVex, visited);
	}

	// Hàm thực hiện BFS từ một đỉnh với trạng thái đã thăm
	private void BFSGraph(int startVex, boolean[] visited) {
		Queue<Integer> queue = new LinkedList<>();
		queue.add(startVex);
		visited[startVex] = true;
		
		System.out.println("Thăm đỉnh: "+startVex);
		

		while (!queue.isEmpty()) {
			int v = queue.poll();

			for (int i = 0; i < numVex; i++) {
				if (matrix[v][i] == 1 && !visited[i]) {
					queue.add(i);
					visited[i] = true;
					System.out.println("Thăm đỉnh " + i);
				}
			}
		}
	}

	// Câu 14. Phương thức dùng giải thuật DFS duyệt đồ thị
	public void DFSGraph() {
		boolean[] visited = new boolean[numVex + 1]; // Mảng đánh dấu đã thăm
		System.out.println("Bắt đầu DFS toàn bộ đồ thị:");

		for (int i = 1; i <= numVex; i++) {
			if (!visited[i]) {
				System.out.println("Bắt đầu DFS từ đỉnh " + i);
				DFSRecursive(i, visited);
			}
		}
	}

	// Hàm DFS đệ quy
	private void DFSRecursive(int v, boolean[] visited) {
		visited[v] = true;
		System.out.println("Thăm đỉnh " + v);

		for (int i = 1; i <= numVex; i++) {
			if (matrix[v - 1][i - 1] == 1 && !visited[i]) {
				System.out.println("Đi từ " + v + " đến " + i);
				DFSRecursive(i, visited);
			}
		}
	}

	// Hàm thực hiện DFS từ một đỉnh
	public void DFSGraph(int startVex) {
		boolean[] visited = new boolean[numVex + 1];
		System.out.println("Bắt đầu DFS từ đỉnh " + startVex);
		DFSRecursive(startVex, visited);
	}

	// Câu 15. Kiểm tra tính liên thông bằng giải thuật BFS hoặc DFS
	public boolean isConnected() {
		boolean[] visited = new boolean[numVex];

		// Bắt đầu duyệt từ đỉnh đầu tiên (thường là 0)
		BFS(0, visited);

		// Kiểm tra nếu còn đỉnh chưa thăm thì đồ thị không liên thông
		for (boolean v : visited) {
			if (!v) {
				return false;
			}
		}

		return true;
	}

	// Thuật toán BFS để duyệt toàn bộ đồ thị
	private void BFS(int startVex, boolean[] visited) {
		Queue<Integer> queue = new LinkedList<>();
		queue.add(startVex);
		visited[startVex] = true;
		System.out.println("Bắt đầu từ đỉnh " + startVex);

		while (!queue.isEmpty()) {
			int v = queue.poll();
			System.out.println("Đang thăm đỉnh " + v);

			for (int i = 0; i < numVex; i++) {
				if (matrix[v][i] == 1 && !visited[i]) {
					queue.add(i);
					visited[i] = true;
					System.out.println("Thêm đỉnh " + i + " vào hàng đợi");
				}
			}
		}
	}

	// Câu 16. Phương thức tìm đường đi giữa 2 đỉnh từ s tới t bằng thuật toán DFS
	// hay BFS
	public void findPathTwoVexs(int s, int t) {
		boolean[] visited = new boolean[numVex];
		int[] parent = new int[numVex]; // Mảng lưu cha của từng đỉnh
		Arrays.fill(parent, -1); // Khởi tạo tất cả cha là -1

		Queue<Integer> queue = new LinkedList<>();
		queue.add(s);
		visited[s] = true;

		System.out.println("Bắt đầu tìm đường từ " + s + " đến " + t);

		while (!queue.isEmpty()) {
			int v = queue.poll();
			System.out.println("Đang xét đỉnh " + v);

			// Nếu tìm thấy đỉnh t thì dừng lại
			if (v == t) {
				break;
			}

			// Duyệt các đỉnh kề
			for (int i = 0; i < numVex; i++) {
				if (matrix[v][i] == 1 && !visited[i]) {
					queue.add(i);
					visited[i] = true;
					parent[i] = v; // Lưu cha của i là v
					System.out.println("Thêm đỉnh " + i + " vào hàng đợi, cha là " + v);
				}
			}
		}

		// Truy vết lại đường đi từ t về s
		if (!visited[t]) {
			System.out.println("Không có đường đi từ " + s + " đến " + t);
			return;
		}

		List<Integer> path = new ArrayList<>();
		for (int v = t; v != -1; v = parent[v]) {
			path.add(v);
		}
		Collections.reverse(path); // Đảo ngược đường đi

		// In đường đi tìm được
		System.out.print("Đường đi từ " + s + " đến " + t + ": ");
		for (int i = 0; i < path.size(); i++) {
			if (i != 0)
				System.out.print(" -> ");
			System.out.print(path.get(i));
		}
		System.out.println();
		System.out.println();
	}

	// Câu 17. Phương thức kiểm tra đồ thị lưỡng phân hay không
	public boolean checkBipartiteGraph() {
		int[] colors = new int[numVex]; // Mảng lưu màu của từng đỉnh (0: chưa tô, 1 và 2: hai màu khác nhau)
		Arrays.fill(colors, 0); // Ban đầu chưa có đỉnh nào được tô màu

		// Kiểm tra từng thành phần liên thông (tránh bỏ sót đồ thị không liên thông)
		for (int start = 0; start < numVex; start++) {
			if (colors[start] == 0) { // Nếu đỉnh chưa được tô màu, thực hiện BFS từ đó
				if (!BFSCheckBipartite(start, colors)) {
					return false; // Nếu phát hiện đồ thị không lưỡng phân thì trả về false ngay
				}
			}
		}
		return true; // Nếu không có lỗi nào, đồ thị là lưỡng phân
	}

	// 🔹 BFS kiểm tra lưỡng phân và tô màu
	private boolean BFSCheckBipartite(int start, int[] colors) {
		Queue<Integer> queue = new LinkedList<>();
		queue.add(start);
		colors[start] = 1; // Tô màu đỉnh đầu tiên là 1
		System.out.println("Bắt đầu kiểm tra từ đỉnh " + start);

		while (!queue.isEmpty()) {
			int u = queue.poll();
			System.out.println("Đang xét đỉnh " + u + " với màu " + colors[u]);

			for (int v = 0; v < numVex; v++) {
				if (matrix[u][v] == 1) { // Nếu có cạnh nối u → v
					if (colors[v] == 0) { // Nếu đỉnh v chưa được tô màu
						colors[v] = (colors[u] == 1) ? 2 : 1; // Tô màu khác với u
						System.out.println("Tô màu đỉnh " + v + " là " + colors[v]);
						queue.add(v);
					} else if (colors[v] == colors[u]) { // Nếu hai đỉnh kề có cùng màu
						System.out.println("Lỗi: Đỉnh " + u + " và đỉnh " + v + " có cùng màu " + colors[u]);
						return false;
					}
				}
			}
		}
		return true;
	}

	// Câu 19. Phương thức kiểm tra đồ thị G có đường đi Euler hay không?
	public abstract boolean isHalfEulerGraph();

	// Câu 18. Phương thức kiểm tra đồ thị G có chu trình Euler hay không?
	public abstract boolean isEulerGraph();
	// Câu 20. Viết phương thức tìm chu trình Ueler đồ thi G
	public abstract void findEulerCycle();
}
