package BaiTapLTDT;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class UndirectionGraph extends Graph {
	
	public UndirectionGraph(int numVex, int[][] matrix) {
		super(numVex, matrix);
	}

	// Câu 5. Phương thức thêm một cạnh vào đồ thị
	@Override
	public void addEdge(int[][] matrix, int v1, int v2) {
		if (v1 < 0 || v2 < 0 || v1 >= matrix.length || v2 >= matrix.length) {
			System.out.println("Lỗi: Đỉnh không hợp lệ.");
			return;
		}
		matrix[v1][v2] = 1;
		matrix[v2][v1] = 1; // Đối xứng cho đồ thị vô hướng
	}

	// Câu 6. Phương thức xóa một cạnh
	@Override
	public void removeEdge(int[][] matrix, int v1, int v2) {
		if (v1 < 0 || v2 < 0 || v1 >= matrix.length || v2 >= matrix.length) {
			System.out.println("Lỗi: Đỉnh không hợp lệ.");
			return;
		}
		if (matrix[v1][v2] == 0) {
			System.out.println("Cạnh (" + v1 + ", " + v2 + ") không tồn tại.");
			return;
		}
		matrix[v1][v2] = 0;
		matrix[v2][v1] = 0; // Xóa đối xứng cho đồ thị vô hướng
		System.out.println("Đã xóa cạnh (" + v1 + ", " + v2 + ")");
	}

	// Câu 7. Phương thức tính bậc của mỗi đỉnh
	@Override
	public int deg(int v) {
		if (v < 0 || v >= matrix.length) {
			System.out.println("Lỗi: Đỉnh không hợp lệ.");
			return -1;
		}
		int degree = 0;
		for (int i = 0; i < matrix.length; i++) {
			degree += matrix[v][i]; // Tổng số cạnh liên kết với đỉnh v
		}
		return degree;
	}

	// Câu 8. Phương thức tính tổng bậc của đồ thị
	public int sumDeg() {
		int sum = 0;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				sum += matrix[i][j]; // Mỗi cạnh được tính hai lần
			}
		}
		return sum; // Trả về tổng bậc
	}

	// Câu 10. Phương thức tính tổng số cạnh của đồ thị
	public int numEdges() {
		if (matrix == null)
			return 0; // Kiểm tra ma trận rỗng

		int count = 0;
		int n = matrix.length;

		// Duyệt qua ma trận để đếm số cạnh
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (matrix[i][j] != 0) {
					count++;
				}
			}
		}
		return count / 2;
	}

	// Câu 12, Phương thức tìm các đỉnh liên thông
	@Override
	public void diTimCacDinhLienThong(boolean[] visited, int start, List<Integer> component) {
		Stack<Integer> stack = new Stack<>();
		stack.push(start);

		while (!stack.isEmpty()) {
			int v = stack.pop();
			if (!visited[v]) {
				visited[v] = true;
				component.add(v);
				System.out.println("Thăm đỉnh " + v);

				for (int i = 0; i < numVex; i++) {
					if (matrix[v][i] == 1 && !visited[i]) {
						System.out.println(" -> Đẩy đỉnh " + i + " vào ngăn xếp để thăm tiếp theo.");
						stack.push(i);
					}
				}
			}
		}
	}

	// CÂu 12. Phương thức xét tính liên thông của đồ thị
	@Override
	public void xetTinhLienThong() {
		boolean[] visited = new boolean[numVex];
		Arrays.fill(visited, false);
		int count = 0;
		List<List<Integer>> components = new ArrayList<>();

		System.out.println("Bắt đầu xét các thành phần liên thông:");

		for (int i = 0; i < numVex; i++) {
			if (!visited[i]) {
				count++;
				System.out.println("Tìm thành phần liên thông thứ " + count + " bắt đầu từ đỉnh " + i);
				List<Integer> component = new ArrayList<>();
				diTimCacDinhLienThong(visited, i, component);
				components.add(component);
			}
		}

		System.out.println("Số thành phần liên thông: " + count);
		for (int i = 0; i < components.size(); i++) {
			System.out.println("Thành phần liên thông " + (i + 1) + ": " + components.get(i));
		}

		if (count == 1) {
			System.out.println("Đồ thị liên thông.");
		} else {
			System.out.println("Đồ thị không liên thông.");
		}
	}

	// Câu 19. Phương thức kiểm tra đồ thị G có đường đi Euler hay không?
	@Override
	public boolean isHalfEulerGraph() {
		// Kiểm tra liên thông
		if (!isConnected()) {
			return false;
		}

		// Đếm số đỉnh có bậc lẻ
		int oddCount = 0;
		for (int i = 0; i < numVex; i++) {
			int degree = 0;
			for (int j = 0; j < numVex; j++) {
				if (matrix[i][j] != 0) {
					degree++;
				}
			}
			if (degree % 2 != 0) {
				oddCount++;
			}
		}

		// Chỉ có đường đi Euler nếu có 0 hoặc 2 đỉnh bậc lẻ
		return (oddCount == 0 || oddCount == 2);
	}

	// Câu 18. Phương thức kiểm tra đồ thị G có chu trình Euler hay không?
	@Override
	public boolean isEulerGraph() {
		// Kiểm tra liên thông
		if (!isConnected()) {
			return false;
		}

		// Kiểm tra tất cả các đỉnh có bậc chẵn
		for (int i = 0; i < numVex; i++) {
			int degree = 0;
			for (int j = 0; j < numVex; j++) {
				if (matrix[i][j] != 0) {
					degree++;
				}
			}
			if (degree % 2 != 0) {
				return false;
			}
		}

		// Nếu tất cả các đỉnh có bậc chẵn -> Có chu trình Euler
		return true;
	}
	// câu 20
	
	@Override

	public void findEulerCycle() {
		if (!isConnected()) {
	        System.out.println("Không tồn tại chu trình Euler vì đồ thị không liên thông.");
	        return;
	    }

	    // Kiểm tra tất cả các đỉnh có bậc chẵn
	    for (int i = 0; i < numVex; i++) {
	        if (deg(i) % 2 != 0) {
	            System.out.println("Không tồn tại chu trình Euler vì có đỉnh bậc lẻ.");
	            return;
	        }
	    }

	    // Tìm chu trình Euler bằng thuật toán Fleury
	    Stack<Integer> stack = new Stack<>();
	    List<Integer> cycle = new ArrayList<>();
	    int[][] tempMatrix = new int[numVex][numVex];

	    // Copy ma trận để không ảnh hưởng dữ liệu gốc
	    for (int i = 0; i < numVex; i++) {
	        for (int j = 0; j < numVex; j++) {
	            tempMatrix[i][j] = matrix[i][j];
	        }
	    }

	    stack.push(0); // Bắt đầu từ đỉnh 0

	    while (!stack.isEmpty()) {
	        int v = stack.peek();
	        boolean hasEdge = false;

	        for (int u = 0; u < numVex; u++) {
	            if (tempMatrix[v][u] > 0) {
	                stack.push(u);
	                tempMatrix[v][u]--;
	                tempMatrix[u][v]--; // Xóa cạnh đối xứng
	                hasEdge = true;
	                break;
	            }
	        }

	        if (!hasEdge) {
	            cycle.add(stack.pop());
	        }
	    }

	    System.out.println("Chu trình Euler: " + cycle);
	    
	}
	// câu 21 đường đi
	
	
}