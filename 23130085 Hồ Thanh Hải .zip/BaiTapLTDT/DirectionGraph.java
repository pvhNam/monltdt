package BaiTapLTDT;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class DirectionGraph extends Graph {

	public DirectionGraph(int numVex, int[][] matrix) {
		super(numVex, matrix);
	}

	// Câu 5. Phương thức thêm một cạnh vào đồ thị
	@Override
	public void addEdge(int[][] matrix, int v1, int v2) {
		if (v1 < 0 || v2 < 0 || v1 >= matrix.length || v2 >= matrix.length) {
			System.out.println("Lỗi: Đỉnh không hợp lệ.");
			return;
		}
		matrix[v1][v2] = 1; // Chỉ thêm theo một chiều
	}

	// Câu 6. Phương thức xóa một cạnh
	@Override
	public void removeEdge(int[][] matrix, int v1, int v2) {
		if (v1 < 0 || v2 < 0 || v1 >= matrix.length || v2 >= matrix.length) {
			System.out.println("Lỗi: Đỉnh không hợp lệ.");
			return;
		}
		if (matrix[v1][v2] == 0) {
			System.out.println("Cạnh (" + v1 + " → " + v2 + ") không tồn tại.");
			return;
		}
		matrix[v1][v2] = 0; // Chỉ xóa một chiều
		System.out.println("Đã xóa cạnh (" + v1 + " → " + v2 + ")");
	}

	// Câu 7. Phương thức tính bậc của mỗi đỉnh
	@Override
	public int deg(int v) {
		if (v < 0 || v >= matrix.length) {
			System.out.println("Lỗi: Đỉnh không hợp lệ.");
			return -1;
		}

		int inDegree = 0, outDegree = 0;

		for (int i = 0; i < matrix.length; i++) {
			outDegree += matrix[v][i]; // Bậc ra: Tổng hàng `v`
			inDegree += matrix[i][v]; // Bậc vào: Tổng cột `v`
		}

		return inDegree + outDegree;
	}

	// Câu 8. Phương thức tính tổng bậc của đồ thị
	public int sumDeg() {
		int sum = 0;
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				sum += Math.abs(matrix[i][j]); // Tổng bậc ra + bậc vào
			}
		}
		return sum; // Tổng bậc của tất cả các đỉnh = tổng số cạnh
	}

	// Câu 10. Phương thức tính tổng số cạnh của đồ thị
	@Override
	public int numEdges() {
		if (matrix == null)
			return 0; // Kiểm tra ma trận rỗng

		int count = 0;
		int n = matrix.length;

		// Duyệt qua ma trận để đếm số cạnh
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (matrix[i][j] != 0) {
					count++;
				}
			}
		}
		return count;
	}

	// CÂu 12. Phương thức xét tính liên thông của đồ thị
	@Override
	public void xetTinhLienThong() {
		boolean[] visited = new boolean[numVex];
		Arrays.fill(visited, false);
		int count = 0;
		List<List<Integer>> components = new ArrayList<>();

		System.out.println("Bắt đầu xét các thành phần liên thông:");

		for (int i = 0; i < numVex; i++) {
			if (!visited[i]) {
				count++;
				System.out.println("Tìm thành phần liên thông thứ " + count + " bắt đầu từ đỉnh " + i);
				List<Integer> component = new ArrayList<>();
				diTimCacDinhLienThong(visited, i, component);
				components.add(component);
			}
		}

		System.out.println("Số thành phần liên thông: " + count);
		for (int i = 0; i < components.size(); i++) {
			System.out.println("Thành phần liên thông " + (i + 1) + ": " + components.get(i));
		}

		if (count == 1) {
			System.out.println("Đồ thị liên thông.");
		} else {
			System.out.println("Đồ thị không liên thông.");
		}
	}

	// Câu 12, Phương thức tìm các đỉnh liên thông
	@Override
	public void diTimCacDinhLienThong(boolean[] visited, int start, List<Integer> component) {
		Stack<Integer> stack = new Stack<>();
		stack.push(start);

		while (!stack.isEmpty()) {
			int v = stack.pop();
			if (!visited[v]) {
				visited[v] = true;
				component.add(v);
				System.out.println("Thăm đỉnh " + v);

				for (int i = 0; i < numVex; i++) {
					if (matrix[v][i] == 1 && !visited[i]) {
						System.out.println(" -> Đẩy đỉnh " + i + " vào ngăn xếp để thăm tiếp theo.");
						stack.push(i);
					}
				}
			}
		}
	}

	// Câu 19. Phương thức kiểm tra đồ thị G có đường đi Euler hay không?
	@Override
	public boolean isHalfEulerGraph() {
		// Kiểm tra liên thông mạnh hoặc yếu
		if (!isConnected()) {
			return false;
		}

		int[] inDegree = new int[numVex];
		int[] outDegree = new int[numVex];

		// Tính bậc vào và bậc ra
		for (int i = 0; i < numVex; i++) {
			for (int j = 0; j < numVex; j++) {
				if (matrix[i][j] != 0) {
					outDegree[i]++;
					inDegree[j]++;
				}
			}
		}

		int startCount = 0, endCount = 0;
		// Kiểm tra điều kiện Euler đường đi
		for (int i = 0; i < numVex; i++) {
			int diff = outDegree[i] - inDegree[i];
			if (diff == 1) {
				startCount++;
			} else if (diff == -1) {
				endCount++;
			} else if (diff != 0) {
				return false;
			}
		}

		// Phải có đúng 1 đỉnh có out-degree = in-degree + 1 và 1 đỉnh có in-degree =
		// out-degree + 1
		return (startCount == 1 && endCount == 1);
	}

	// Câu 18. Phương thức kiểm tra đồ thị G có chu trình Euler hay không?
	// Hàm kiểm tra liên thông mạnh
	public boolean isStronglyConnected() {
		return false;
		
	}

	@Override
	public boolean isEulerGraph() {
		// TODO Auto-generated method stub
		return false;
	}
// câu 20
	
	@Override
	public void findEulerCycle() {
		// TODO Auto-generated method stub
		
	}

}
